# Translation task (Arabic → English)

You translate short essays and aphorisms by an Arabic Islamic writer (Ustadh Faraj) into English for a reading archive.

Input files are in `in/` (UTF-8). Each post starts with a line `@@ID <number>` followed by its Arabic text (paragraphs separated by line breaks) until the next `@@ID`.

For EVERY post write, in the same order:

```
@@ID <number>
@@TITLE <English title>
<English translation, same paragraph breaks as the Arabic>
```

Rules:
- Translate the Arabic faithfully and completely into natural, clear English. Do not summarise, skip, soften, embellish or add commentary, notes or explanations of your own. No translator's notes.
- Keep every paragraph/line break of the source. Keep emojis, symbols, numbers, URLs, hashtags and Latin-script words as they are.
- Qur'an verses: translate the meaning in plain English inside quotation marks; keep the surah/verse reference if the source gives one. Hadith: translate plainly.
- Use common English Islamic conventions: Allah; the Prophet ﷺ (keep ﷺ where the source has a salutation; "peace be upon him" for other prophets); Qur'an; Sunnah; Ummah; Mahdi; Dajjal; Barzakh; jihad; names in common English spelling (Umar, Ali, Aisha, Musa/Moses as fits).
- The author sometimes writes words in a disguised way (mixed Latin letters, e.g. "الدJال", "غZة"); translate the intended word normally (Dajjal, Gaza).
- `@@TITLE`: if the first line of the post is itself a heading, use its translation (without a trailing colon). Otherwise use the translated opening sentence or phrase, at most about 90 characters (end with "…" if cut). Do not invent catchy titles.
- Do not write anything else in the output files: no preface, no markdown, no closing remarks.
- This is the author's own religious, social and political commentary; translate it as written, in his voice.
- Exception: if a post directly calls on people to kill, torture or otherwise physically attack particular people or groups, or declares someone's blood, life or "honor" lawful (sanctioning killing or sexual violence), do NOT translate it. Write only `@@ID <number>` followed by a line `@@SKIP` for that post, and name those ids in your reply. Descriptions of war, history, prophecy, political analysis, prayers against oppressors and criticism — however harsh — are not this exception and must be translated normally.

Output: write the result for input file `in/B017.txt` to `out/B017_1.txt`, `out/B017_2.txt`, … — several part files, each holding complete posts and at most roughly 2,500 English words, so that no single write is too long. Every post of the input must appear exactly once across the parts, in order.

When done, verify with:
`python3 -I check.py B017`  (prints OK or lists missing/extra ids) and fix until it prints OK.
Reply with only one line: the batch names and OK, plus any skipped ids.
